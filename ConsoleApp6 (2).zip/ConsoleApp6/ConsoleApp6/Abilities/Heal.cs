﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ConsoleApp6.Core;

namespace ConsoleApp6.Abilities
{
    public class Heal
    {
        public static void healPlayer(int pointsHealed)
        {
            Player player = Game.Player;
            player.Health += pointsHealed;
        }
    }
}
