﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RLNET;
using RogueSharp;

namespace ConsoleApp6.Core
{
    public class Player : Actor
    {
        public int potions = 3;
        public Player()
        {
            Attack = 2;
            AttackChance = 50;
            Awareness = 15;
            Defense = 2;
            DefenseChance = 40;
            Gold = 0;
            Health = 100;
            MaxHealth = 100;
            Speed = 10;
            Name = "Rogue";
            Color = Colors.Player;
            Symbol = '@';
            X = 10;
            Y = 10;
        }
        public void DrawStats( RLConsole statConsole)
        {
            statConsole.Print(1, 1, $"Name: {Name}", Colors.Text);
            statConsole.Print(1, 3, $"Health: {Health}", Colors.Text);
            statConsole.Print(1, 5, $"Potions: {potions}", Colors.Text);
            statConsole.Print(1, 7, $"Attack: {Attack}", Colors.Text);
            statConsole.Print(1, 9, $"Defense: {Defense}", Colors.Text);
            statConsole.Print(1, 11, $"Awareness: {Awareness}", Colors.Text);
            statConsole.Print(1, 13, $"Speed: {Speed}", Colors.Text);
            statConsole.Print(1, 16, $"Gold: {Gold}", Colors.Gold);
        }
        public void Heal()
        {
            if(potions > 0)
            {
                Game.Player.Health += 15;
                potions--;
            }
            
        }
    }
}
