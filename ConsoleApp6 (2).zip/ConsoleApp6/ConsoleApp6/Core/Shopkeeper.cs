﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ConsoleApp6.Interfaces;
using RLNET;
using RogueSharp;

namespace ConsoleApp6.Core
{
    public class Shopkeeper : Actor , IDrawable
    {
        public Shopkeeper()
        {
            Attack = 0;
            AttackChance = 0;
            Awareness = 15;
            Defense = 10;
            DefenseChance = 100;
            Gold = 1000000;
            Health = 100000;
            MaxHealth = 100000;
            Speed = 0;
            Name = "Shopkeeper";
            Color = Colors.Player;
            Symbol = '$';
            List<IItem> ItemInventory = new List<IItem>();
        }
    }
}
