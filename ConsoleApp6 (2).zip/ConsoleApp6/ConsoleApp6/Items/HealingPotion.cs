﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ConsoleApp6.Interfaces;
using ConsoleApp6.Abilities;

namespace ConsoleApp6.Items
{
    public class HealingPotion : IItem
    {
        public string Name { get; }
        public int RemainingUses { get; private set; }

        public HealingPotion()
        {
            Name = "Potion of Healing";
            RemainingUses = 1;
        }
        public bool Use()
        {
            Heal.healPlayer(15);
            RemainingUses--;
            return true;
        }
    }
}
