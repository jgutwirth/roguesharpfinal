public class Actor : IActor, IDrawable{
	public string name {get; set;}
	public int awareness {get; set;}

	public RLColor color {get; set;}
	public char symbol {get; set;}
	public int x {get; set;}
	public int y {get; set;}
	public void Draw(RLConsole console, IMap map){
		if(!map.getCell(x, y).IsExplored){
			return;
		}
		if(map.IsInFOV(x, y)){
			console.Set(x, y, color, Colors.FloorBackgroundFOV, symbol);
		}
		else{
			console.Set(x, y, Colors.Floor, Colors.FloorBackground, '.');
		}
	}
}