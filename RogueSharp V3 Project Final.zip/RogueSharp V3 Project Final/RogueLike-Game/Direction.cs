namespace RogueSharp V3 Project.Core{
	public enum Direction{
		None = 0,
		DownLeft = 'a'+'s',
		Down = 's',
		DownRight = 's'+'d',
		Left = 'a',
		Right = 'd',
		UpLeft = 'a'+'w',
		UpRight = 'd'+'w',
		Up = 'w'
	}
}