public class DungeonMap:Map{
		public void Draw(RLConsole mapConsole){
			mapConsole.clear();
			foreach(Cell cell in GetAllCells() ){
				SetConsoleSymbolForCell(mapConsole, cell);
			}
		}

		private void SetConsoleSymbolForCell(RLConsole console, Cell cell){
			if( !cell.IsExplored){
				return;
			}

			if(IsInFOV( cell.x, cell.y)){
				if(cell.IsWalkable){
					console.Set(cell.x, cell.y, Colors.FloorFOV, Colors.FloorBackgroundFOV, '.');
				}
				else{
					console.Set(cell.x, cell.y, Colors.WallFOV, Colors.WallBackgroundFOV, '#');
				}
			}
			else{
				if(cell.IsWalkable){
					console.Set(cell.x, cell.y, Colors.Floor, Colors.FloorBackground, '.');
				}
				else{
					console.Set(cell.x, cell.y, Colors.Wall, Colors.WallBackground, '#');
				}
			}
		}
		public void UpdatePlayerFieldOfView(){
			Player player = Game.Player;
			ComputeFov(player.x, player.y, player.awareness, true);
			foreach(Cell cell in GetAllCells()){
				if(IsInFOV(cell.x, cell.y)){
					SetCellProperties(cell.x, cell.y, cell.IsTransparent, cell.IsWalkable, true);
				}
			}
		}
	}