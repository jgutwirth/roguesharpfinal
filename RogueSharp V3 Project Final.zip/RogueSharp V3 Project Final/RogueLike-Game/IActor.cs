namespace Roguesharp V3 Project.Interfaces{
	public interface IActor{
		string name {get; set;}
		int awareness {get; set;}
	}
}