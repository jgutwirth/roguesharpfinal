public interface IDrawable{
		RLColor color {get; set;}
		char symbol {get; set;}
		int x {get; set;}
		int y {get; set;}

		void Draw(RLConsole console, IMap map);
	}