namespace RogueSharp V3 Project.core{
	public class Player : Actor{
		public Player(){
			awareness = 15;
			name = "Rogue";
			color = Colors.Player;
			symbol = '@';
			x = 10;
			y = 10;
		}
	}
}