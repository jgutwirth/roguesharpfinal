public class Swatch{

		//main colors
		public static RLColor PrimaryLightest = new RLColor(113, 167, 110);
		public static RLColor PrimaryLighter = new RLColor(82, 148, 79);
		public static RLColor Primary = new RLColor(59, 132, 55);
		public static RLColor PrimaryDarker = new RLColor(37, 115, 33);
		public static RLColor PrimaryDarkest = new RLColor(12, 88, 8);

		public static RLColor SecondaryLightest = new RLColor(189, 99, 142);
		public static RLColor SecondaryLighter = new RLColor(86, 74, 126);
		public static RLColor Secondary = new RLColor(68, 54, 112);
		public static RLColor SecondaryDarker = new RLColor(51, 36, 98);
		public static RLColor SecondaryDarkest = new RLColor(29, 15, 75);

		public static RLColor AlternateLightest = new RLColor(206, 194, 136);
		public static RLColor AlternateLighter = new RLColor(183, 168, 97);
		public static RLColor Alternate = new RLColor(163, 146, 67);
		public static RLColor AlternateDarker = new RLColor(142, 125, 41);
		public static RLColor AlternateDarkest = new RLColor(109, 92, 10);

		public static RLColor ComplimentLightest = new RLColor(205, 135, 137);
		public static RLColor ComplimentLighter = new RLColor(182, 96, 98);
		public static RLColor Compliment = new RLColor(161, 67, 69);
		public static RLColor ComplimentDarker = new RLColor(141, 40, 43);
		public static RLColor ComplimentDarkest = new RLColor(108, 10, 13);

		//custom colors
		public static RLColor DbDark = new RLColor( 20, 12, 28 );
    	public static RLColor DbOldBlood = new RLColor( 68, 36, 52 );
    	public static RLColor DbDeepWater = new RLColor( 48, 52, 109 );
    	public static RLColor DbOldStone = new RLColor( 78, 74, 78 );
    	public static RLColor DbWood = new RLColor( 133, 76, 48 );
    	public static RLColor DbVegetation = new RLColor( 52, 101, 36 );
    	public static RLColor DbBlood = new RLColor( 208, 70, 72 );
    	public static RLColor DbStone = new RLColor( 117, 113, 97 );
    	public static RLColor DbWater = new RLColor( 89, 125, 206 );
    	public static RLColor DbBrightWood = new RLColor( 210, 125, 44 );
    	public static RLColor DbMetal = new RLColor( 133, 149, 161 );
    	public static RLColor DbGrass = new RLColor( 109, 170, 44 );
    	public static RLColor DbSkin = new RLColor( 210, 170, 153 );
    	public static RLColor DbSky = new RLColor( 109, 194, 202 );
    	public static RLColor DbSun = new RLColor( 218, 212, 94 );
    	public static RLColor DbLight = new RLColor( 222, 238, 214 );
	}